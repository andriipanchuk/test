#!/bin/bash

BASEDIR=$(dirname $(readlink -f $0))
cfgfile="$BASEDIR/../../../../xi-sys.cfg"
cfgfile_installed="/usr/local/nagiosxi/var/xi-sys.cfg"

if [ -f $cfgfile ]; then
    . $cfgfile
elif [ -f $cfgfile_installed ]; then
    . $cfgfile_installed
fi

if [ `command -v yum` ]; then
	if [ "$dist" == "el8" ]; then
		yum install whois -y
	else
    	yum install jwhois -y
    fi
else
    apt-get install -y whois
fi
exit 0
