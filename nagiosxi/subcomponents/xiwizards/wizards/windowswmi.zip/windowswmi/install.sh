#!/bin/bash

BASEDIR=$(dirname $(readlink -f $0))
cd $BASEDIR

. $BASEDIR/../../../../var/xi-sys.cfg

package="wmi-1.3.14"

if [ -f /usr/local/bin/wmic ] || [ -f /usr/bin/wmic ]; then
    echo "wmic has already been installed... skipping compile"
    exit 0;
fi

# Install pre-reqs and cpan pre-reqs
if [ "$distro" == "Debian" ] || [ "$distro" == "Ubuntu" ]; then
    cpan install Getopt::Long DateTime Config::IniFiles List::MoreUtils ||:
else
    echo | cpan Getopt::Long
    yum install -y perl-DateTime perl-Config-IniFiles perl-List-MoreUtils
fi

(    
    # Download
    cd /tmp
    wget "https://assets.nagios.com/downloads/nagiosxi/agents/$package.tar.gz"
    tar xf "$package.tar.gz"
    cd $package

    # Required to get the binary to build
    if [ "$dist" == "debian9" ] || [ "$dist" == "debian10" ] || [ "$dist" == "ubuntu16" ] || [ "$dist" == "ubuntu18" ] || [ "$dist" == "ubuntu20" ] || [ "$dist" == "el8" ]; then
        ofl=`ulimit -n`
        if [ $ofl -lt 2048 ]; then
            ulimit -n 2048
        fi
        sed -i 's/defined @$pidl/@$pidl/' Samba/source/pidl/pidl
    fi
    
    # Build (configure happens in make ...)
    make "CPP=gcc -E -ffreestanding"

    # Copy the binary to location and link
    cp -f Samba/source/bin/wmic /usr/local/bin
    cp -f Samba/source/bin/winexe /usr/local/bin
    ln -s /usr/local/bin/wmic /usr/bin/wmic
    ln -s /usr/local/bin/winexe /usr/bin/winexe

    # Cleanup
    cd /tmp
    rm -rf "$package.tar.gz"
    rm -rf "$package"
)

exit 0
