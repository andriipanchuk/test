<?php

/*****************************************************************************
 *
 * GlobalBackendndomy.php - backend class for handling object and state
 *                           information stored in the NDO database.
 *
 * Copyright (c) 2004-2016 NagVis Project (Contact: info@nagvis.org)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************/

class GlobalBackendndomy extends GlobalBackendPDO
{
    public function driverName() {
        return 'mysql';
    }

    /**
     * Sends acknowledgement command to nagios core
     * ADDED BY NAGIOS ENTERPRISES
     */
    public function actionAcknowledge($what, $spec, $comment, $sticky, $notify, $persist, $user)
    {
        $base = realpath(dirname(__FILE__).'/../../../../../');
        define('CFG_ONLY', true);
        require_once($base.'/nagiosxi/html/config.inc.php');

        if ($what == 'host') {
            $what = 'HOST';
        } else if ($what == 'service') {
            $what = 'SVC';
        }

        $sticky  = $sticky ? '2' : '0';
        $notify  = $notify ? '1' : '0';
        $persist = $notify ? '1' : '0';

        $cmd = 'ACKNOWLEDGE_'.$what.'_PROBLEM;'.$spec.';'.$sticky.';'.$notify.';'.$persist.';'.$user.';'.$comment;

        $command_file = $cfg['component_info']['nagioscore']['cmd_file'];

        if (file_exists($command_file) == false) {
            $output = "ERROR: Command file does not exist";
            return false;
        }

        if (($fp = @fopen($command_file, "w")) == false) {
            $output = "ERROR: Could not open command file";
            return false;
        }
        $now = time();
        $command = sprintf("[%lu] %s\n", $now, $cmd);
        fputs($fp, $command);
        fclose($fp);
    }
}
