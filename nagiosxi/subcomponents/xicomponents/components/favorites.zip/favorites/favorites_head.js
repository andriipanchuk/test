$(document).ready(function() {
	var favorites_ajax = base_url + 'includes/components/favorites/favorites_ajax.php';
	$('.favorites_icon').click(function() {

		// Get iframe url - we're inside the iframe so this is just window.
		var href = window.location.href;
		var partial_href = href.split(base_url).join('');

		// Same goes for the interior title - just refer to document
		var title = document.title;
		title = title.split(' · Nagios XI').join('');

		var user_id = $(this).data('user-id');

		/* Now send this to the database */
		var query = { partial_href: partial_href, title: title, user_id: user_id, mode: 'add' };
		$.post(favorites_ajax, query, function() {
			favorites_redraw_menu(window.parent, document);
		}, 'json');
	});

	$('.favorites_manage').click(function(e) {
		e.stopPropagation();

		var menusections = $(this).parent().parent().children('.menusection');

		menusections.children('.menulink').hide();
		menusections.children('.favorites_hidden_form').children('li').children('input').each(function() {
			$(this).attr('value', $(this).data('original-value'));
			$(this).parent().show();
		});
		menusections.children('.favorites_hidden_form').show();

		$(this).hide();
		$(this).next().show();
		$(this).next().next().show();
	});

	$('.favorites_save').click(function(e) {
		e.stopPropagation();
		var query = $(this).parent().parent().children().children('.favorites_hidden_form').serialize();
		var mode = { mode: 'edit' };
		$.post(favorites_ajax + '?' + query, mode, function() {
			favorites_redraw_menu(window, $('#maincontentframe').contents()[0]);
		}, 'json');
	});

	$('.favorites_cancel').click(function(e) {
		e.stopPropagation();

		var menusections = $(this).parent().parent().children('.menusection');

		menusections.children('.menulink').show();
		menusections.children('.favorites_hidden_form').hide();

		$(this).hide();
		$(this).next().hide();
		$(this).prev().show();
	});

	$('.favorites_delete').click(function(e) {
		e.stopPropagation();
		$(this).parent().hide();
		var preceding_input = $(this).prev();
		preceding_input.attr('value', '*DELETED*');
	});

	function favorites_redraw_menu(exterior_window, interior_document) {
		window.parent.location.href = get_permalink(exterior_window, interior_document);
	}
});